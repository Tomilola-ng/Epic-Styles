Get Started with epic-styles.github.io offline

1. Decompress the ZIP file

2. Open Decompressed Folder in Your preffered IDE 
    >> Do not change anything in the Packages folder

3. Jump start your project by using the pre created index.html file 

4. Clear Demo Project in the div with id "app"

5. Start Designing with epic-styles classes availaible go to "https://epic-styles.github.io" for the documentation.

6. Once Finished go to the head tag and find this comment : <!-- Start : "Must be deleted During Deployment" --><!-- End : "Must be deleted During Deployment" --> ;

7. Replace the comments and everything in between with this <script src='https://epic-styles.github.io/epic.js'></script>

8. Now test your project and make sure you are ready for the deployingyour code

9. Happy Coding 😀
